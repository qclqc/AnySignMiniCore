"use strict";

/**
 *
 * @param url 导入css 的url地址
 * @param id  link标签的id（必须保证唯一性）
 * @returns {*} export此函数方便全局调用
 */
function addCssLink(url, id, resovle, reject) {
  var _id = "add_css_link" + id;
  // return new HYPromise(function (resovle, reject) {
  var srcArr = document.getElementsByTagName("link");
  var hasLoaded = false;
  for (var i = 0; i < srcArr.length; i++) {
    hasLoaded = srcArr[i].href === url;
    // 如果找到了重复的css标签将它删除
    if (hasLoaded) {
      document.getElementById(_id).remove();
      break;
    }
  }
  var doc = document;
  var link = doc.createElement("link");
  link.setAttribute("rel", "stylesheet");
  link.setAttribute("type", "text/css");
  link.setAttribute("href", url);
  link.setAttribute("id", _id);
  var heads = doc.getElementsByTagName("head");
  if (heads.length) {
    heads[0].appendChild(link);
  } else {
    doc.documentElement.appendChild(link);
  }
  link.onload = function () {
    resovle();
  };
  link.onerror = function () {
    reject();
  };
  // });
}
/**
 *
 * @param url 导入js的url地址
 * @param id  script标签的id（必须保证唯一性）
 * @returns {*} export此函数方便全局调用
 */
function asyncLoadJs_new(url, id, resovle, reject) {
  var _id = "async_load_js_" + id;
  // return new HYPromise(function (resovle, reject) {
  var srcArr = document.getElementsByTagName("script");
  var hasLoaded = false;
  for (var i = 0; i < srcArr.length; i++) {
    hasLoaded = srcArr[i].src === url;
    // 如果找到了重复的js标签将它删除
    if (hasLoaded) {
      document.getElementById(_id).remove();
      break;
    }
  }

  //创建script标签,并为此标签添加ID
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = url;
  script.id = _id;
  script.defer = "defer";
  //添加标签到body尾部
  document.head.appendChild(script);
  script.onload = function () {
    resovle();
  };
  script.onerror = function () {
    reject();
  };
  // });
}

function isInclude(name) {
  var js = /js$/i.test(name);
  var es = document.getElementsByTagName(js ? "script" : "link");
  for (var i = 0; i < es.length; i++)
    if (es[i][js ? "src" : "href"].indexOf(name) != -1) return true;
  return false;
}
var sourceArr = [
  {
    type: 0,
    name: "sp.css",
    url: "./css/sp.css",
    names: "sp",
    child: [
      {
        type: 0,
        name: "anySignPads.css",
        url: "./css/anySignPads.css",
        names: "anySignPads",
        child: [
          {
            type: 0,
            name: "mw480Portrait.css",
            url: "./css/mw480Portrait.css",
            names: "mw480Portrait",
            child: [
              {
                type: 0,
                name: "sw1024.css",
                url: "./css/sw1024.css",
                names: "sw1024",
                child: [
                  {
                    type: 0,
                    name: "canvas_css.css",
                    url: "./css/canvas_css.css",
                    names: "canvas_css"
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  {
    type: 1,
    name: "polyfill.min.js",
    url: "./libs/polyfill.min.js",
    names: "polyfill.min",
    child: [
      {
        type: 1,
        name: "sm3.js",
        url: "./libs/CryptoJS v3.1.2/rollups/sm3.js",
        names: "sm3.min",
        child: [
          {
            type: 1,
            name: "deflate.min.js",
            url: "./libs/zlib/deflate.min.js",
            names: "deflate.min",
            child: [
              {
                type: 1,
                name: "core-min",
                url: "./libs/CryptoJS v3.1.2/components/core-min.js",
                names: "core-min",
                child: [
                  {
                    type: 1,
                    name: "rollups/sha1.js",
                    url: "./libs/CryptoJS v3.1.2/rollups/sha1.js",
                    names: "sha1",
                    child: [
                      {
                        type: 1,
                        name: "tripledes.js",
                        url: "./libs/CryptoJS v3.1.2/rollups/tripledes.js",
                        names: "tripledes",
                        child: [
                          {
                            type: 1,
                            name: "mode-ecb.js",
                            url: "./libs/CryptoJS v3.1.2/components/mode-ecb.js",
                            names: "mode-ecb",
                            child: [
                              {
                                type: 1,
                                name: "anysignCrypto.js",
                                url: "./libs/anysignCrypto.js",
                                names: "anysignCrypto",
                                child: [
                                  {
                                    type: 1,
                                    name: "anySignPadEs5.min.js",
                                    url: "./libs/anySignPadEs5.min.js",
                                    names: "anySignPadEs5.min",
                                    child: [
                                      {
                                        type: 1,
                                        name: "anySignPadWhiteEs5.min.js",
                                        url: "./libs/anySignPadWhiteEs5.min.js",
                                        names: "anySignPadWhiteEs5.min",
                                        child: [
                                          {
                                            type: 1,
                                            name: "anysign_all_stricts.js",
                                            url: "./libs/anysign_all_stricts.js",
                                            names: "anysign_all_stricts",
                                            child: [
                                              {
                                                type: 1,
                                                name: "anysignWebInterfaces.js",
                                                url: "./anysignWebInterfaces.js",
                                                names: "anysignWebInterfaces"
                                              }
                                            ]
                                          }
                                        ]
                                      }
                                    ]
                                  }
                                ]
                              }
                            ]
                          }
                        ]
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  }
];
function loadJsNewJs(res, err) {
  return function loadFiles(sourceArr) {
    for (var i = 0; i < sourceArr.length; i++) {
      var item = sourceArr[i];
      if (item.type == 0) {
        var items = item;
        if (!isInclude(item.name)) {
          addCssLink(
            item.url,
            item.names,
            function () {
              if (items.child) loadFiles(items.child);
            },
            function () {
              err();
            }
          );
        }
      } else {
        if (!isInclude(item.name)) {
          asyncLoadJs_new(
            item.url,
            item.names,
            function () {
              if (item.child) {
                loadFiles(item.child);
              } else {
                res();
              }
            },
            function () {
              err();
            }
          );
        }
      }
    }
  };
}
