# 产品介绍

    当前产品版本：AnySignMiniCoreV2.6.1


# 目录结构描述

    ├── README.md                   	// help
    ├── libs                      	  // 核心文件
    │   ├── CryptoJS v3.1.2			 // 加密
    │   ├── zlib                		// 加密
    │   ├── anysignCrypto.js        	// 加密
    │   ├── anySignPadWhiteEs5.min.js   // 白板签名组件
    │   ├── anySignPadEs5.min.js    	// 田字格签名组件
	│	├── polyfill.min.js				// 兼容优化
    │   └── anysign_all_strict.min.js   // 签名核心文件
    ├── image				   		// 图片资源
    ├── css                         	// 样式资源
    ├── anysignWebInterface.js      	// 签名接口封装
    ├── anySignCoreEntry.js	 		// 核心文件引用
    └── index.html			  		// 入口html

# 使用说明

## 一、初始化 testAnySign()

	设置签名算法；

	初始化接口类，传入签名回调方法、渠道号、加密包必需包含签名或抄录、是否使用告知协议；

	有手写识别情况下，初始化手写识别类

	初始化手写识别结果回调
	
	初始化双录数据开启标识、使用用类型、回调

	初始化签名数据、初始化批注数据

## 二、设置模板数据 testSetTemplateData()/testSetOrgData()

	设置pdf模板或表单模板

## 三、添加证据 testAddEvidence

	添加业务外传证据

## 四、弹签名板 show_agreements()/testCommentDialog()

### （1）调用白板/单字签名板 option选项

#### 参数
	
	通用参数：
		signer // 签名人信息
		signRule // 签名规则
		cid // 加密包id
		anysignTitle // title标签id
		title // 白板签名title
		titleSpanFromOffset // title中需要放大显示字体的起始位置（通常为title中签名人前面文字的字数）
		titleFontColor // title颜色默认黑色
		isTSS // 是否开启 时间戳，默认为false
		nessesary // 是否为必签项（若初始化则必须签），默认为false
		signature_max_times	// 手写识别允许失败最大次数
		timeTag // 签名人信息，为必填项, 1:时间在上、2：时间在下、3：时间在右
		isdistinguish // 是否开启手写识别
		ocrCapture // 手写识别参数
		verificationRequestData.verifyModel	// 设置核验方式 默认不核验
		trackInterval // 间隔多少毫秒返回双录数据，开启双录 ，并且双录类型为1（根据时间间隔回调数据）时生效
	
	单字生效参数
		composeImgNum // 签名图片每行多少字，默认为25（通常根据中签名人名字长度设置）
		singleSignImage // 单字合成图片的dom容器

		
#### 白板手写画布参数 signConfig option选项
		parentId // 画布与提示文字父节点id
		penColor // 画笔颜色
		strokeWidth // 不开启笔锋时画笔宽度
		imageWidth // 生成图片总宽度
		imageHeight // 生成图片总高度
		useLandscape // 强制横屏
		openSmooth // 开启笔锋
		maxWidthDiffRate // 相邻两线宽度增(减)量最大百分比，笔锋参数 1-100 根据实际情况调试满意数值
		minWidth // 笔锋最小宽
		maxWidth // 笔锋最大宽
		minSpeed // 画笔达到最小宽度所需最小速度(px/ms)，值越小，画笔越容易变细，笔锋效果更明显
		
### （2）单字签名手写画布参数 signConfig option选项
		
		parentId // 画布与提示文字父节点id
		hintColor // 提示字颜色
		hintFontSize // 提示字大小
		hintType // 提示文字方式，top，middle，bottom
		otherText // 其他提示文字（提示字设置为top、bottom时生效）
		otherTextColor // 其他提示文字颜色
		background // 画布背景图（支持图片base64）
		penColor // 画笔颜色（十六进制以及字符型（black、gray、red、green、blue、purple、pink、yellow、orange）），默认为黑色
		strokeWidth // 画笔宽度
		imageWidth // 单个字符生成图片宽
		imageHeight // 单个字符生成图片高
		autoConfirm // 是否停笔xxx秒之后生成图片，填入数字则为等待时间（如1：1秒）
		openSmooth // 是否开启笔锋
		maxWidthDiffRate // 相邻两线宽度增(减)量最大百分比，笔锋参数 1-100 根据实际情况调试满意数值
		minWidth // 笔锋最小宽
		maxWidth // 笔锋最大宽
		minSpeed // 画笔达到最小宽度所需最小速度(px/ms)，值越小，画笔越容易变细，笔锋效果更明显
		hintDistanceRate //提示文字在田子格的位置，默认值为0， 数据填写值范围0-50，hintType  top和bottom有效
		

### （3）调用批注签名板 option选项
#### 参数
		signer // 签名人信息
		signRule // 签名规则
		cid // 加密包id
		commitment // 批注内容
		comment_max_times // 批注手写识别错误上限，取值1-99
		nessesary // 是否为必签项（若初始化则必须签），默认为false
		isdistinguish // 是否开启手写识别
		ocrCapture // 手写识别参数
		composeImgNum // 签名图片每行多少字，默认为25（通常根据中签名人名字长度设置）
		anysignTitle // title标签id
		punctuation_recognition // 标点是否可识别
		singleSignImage // 单字合成图片的dom容器
		tipColor // 当前书写文字的颜色
		trackInterval // 间隔多少毫秒返回双录数据，开启双录 ，并且双录类型为1（根据时间间隔回调数据）时生效

#### 批注签名手写画布参数 signConfig option选项
	
	批注手写画布参数同单字签名手写画布参数 signConfig option选项一致

## 五、签名状态位参数（签名/批注）testSignatureStatus()/testCommentStatus()

	不开启识别

		签字完成后输出一个状态位参数0

	开启识别
		
		在识别次数上限内识别通过，输出状态位参数1

		达到识别上限次数仍识别校验不通过，再次签名时不进行手写识别校验，签字完成后输出状态位参数2

## 六、上传数据是否准备就绪 testIsReadyToUpload()

		检测设置nessesary为true签名对象是否存在签名图片、签名轨迹等数据

		检测设置nessesary为true批注对象是否存在批注图片

## 七、生成PDF上传数据/生成文本上传数据 testGenData()/testTextGenData()

		设置pdf模板则调用生成PDF上传数据方法

		设置表单数据则调用生成文本上传数据方法
		
		返回加密包（加密json串）


# 版本内容更新

###### v2.6.1: 

    1、设置PDF模板数据增加原文类别参数：ExternalTemplate:是否计算加密包中PDF原文的SM3的Hash值存放至加密包；
       * 如使用加密包中的原文进行签名，请设为加密包原文类型
       * 如使用了外传原文进行签名，请设为外传原文类型。此版本新增比对Hash功能，请如实设置原文类型
 
# 注 ：

## 双录数据返回格式

 ### setTrackCallback(isUse, syncType, track_Callback) / setTrackCallback(isUse, syncType,(data) => {})

        调用返回数据data
            * signType: 1, //签名方式，1白板签名重力旋转，2白板签名强制横屏，3单字签名，4抄录签名
    		* operation: 0, //操作事件，0正常手写，1确定，2取消，3清空当前，4后退，5修改特定文字，6清空全部，7手动确认（田字格）
    		* signTrackArray: [], //数组，xy坐标交替，-1,0分隔笔画，xy是number
    		* strokeWidth: 10, //笔画粗细
    		* strokeColor: "", //笔画颜色
    		* targetWord: "", //正在写的文字，配合targetIndex帮助确定轨迹内容
    		* targetIndex: 0, //在文字序列的第几个，从0开始，白板签名为0
    		* maxLength: 1, //本次回显的文字数量，白板签名为1
    		* preStrokeStop: 0, //上次传输的时候到哪里，从0开始  signTrackArray数组长度
    		* width: 0, //画布宽，旋转屏幕之后可能会改变
    		* height: 0, //画布高，旋转屏幕之后可能会改变
    		* timeTag: '', //双录数据的时间字段，以打开画布为时间零点，计算时间间隔
